# coding=utf-8
import serial
import time
import sys
import matplotlib.pyplot as plt
import serial.tools.list_ports
from queue import Queue

bps = 115200  # 波特率
timex = None  # 超时设置, None：永远等待操作，0为立即返回请求结果，其他值为等待超时时间(单位为秒）
isENCsteady = False
isADCsteady = False

#####################################################################
#                         设备参数设置区域                             #
#####################################################################
portx = 'COM4'#'/dev/cu.wchusbserial1420'  # 串口名称
useHandMode = True  # 是否启用手动设置
userSetADCaim = 3112  # 手动设置的ADC目标值
userSetdown = 1051  # 手动设置的ADC当前值
userSetENDaim = 10000  # 手动设置的ENC目标值
team_name = 'team_name'  # 队伍名字
#####################################################################
#                          比赛任务难度参数设置区域                     #
#####################################################################
enc_threshold = 75 * 2  # ENC的稳定阈值，正负75
adc_threshold = 170  # ADC的稳定阈值，正负170
steady_time = 3  # 稳定时间，3s

adc_down = 0000  # 倒立位置ADC，和ADCaim差2014
adc_aim = 0000  # 平衡位置ADC

enc_queue = Queue()


def ADCinrange(adc, adc_aim):
    if adc_threshold < adc_aim < 4095 - adc_threshold:
        if abs(adc - adc_aim) < adc_threshold:
            return True
        else:
            return False
    elif adc_aim < adc_threshold:
        if abs(adc - adc_aim) < adc_threshold or adc > 4095 - (adc_threshold - adc_aim):
            return True
        else:
            return False
    else:
        if abs(adc - adc_aim) < adc_threshold or adc < adc_threshold - adc_aim:
            return True
        else:
            return False


def ENCsteady():
    q = enc_queue.queue
    if len(q) < 200 * steady_time:
        return False
    while len(enc_queue.queue) >= 199 * steady_time:
        q = enc_queue.queue
        if abs(max(q) - min(q)) < enc_threshold:
            return True
        enc_queue.get()
    return False


def adc(adc1, adc2):
    ADC = adc1 * 64 + adc2
    data_adc.write(str(ADC) + '\n')
    return ADC


def enc(enc1, enc2, enc3):
    ENC = enc1 * 4096 + enc2 * 64 + enc3
    data_enc.write(str(ENC) + '\n')
    return ENC


data_adc = open(team_name + '_task_1_ADC.txt', 'w')
data_enc = open(team_name + '_task_1_ENC.txt', 'w')

# main
try:
    ser = serial.Serial(portx, bps, timeout=timex)  # 打开串口，并得到串口对象
    ax = []  # 定义一个 x 轴的空列表用来接收动态的数据
    ay = []  # 定义一个 y 轴的空列表用来接收动态的数据
    az = []  # 定义一个 y2 轴的空列表用来接收动态的数据

    t = -1  # 5ms
    endCount = 0
    start_flag = 0
    plt.show()

    if ser.is_open:
        print("串口详情参数：", ser)
        time.sleep(0.1)
        while True:
            #time.sleep(0.001)
            a = ord(ser.read(1))
            if a == 0x7a:
                t = t + 1
                if t == 0:
                    ###########################
                    # 上电记录初值，并以一圈4096的
                    # assumption计算终值
                    # TODO: 目标计算是否合理
                    ###########################
                    adc_1 = ord(ser.read(1)) - 1
                    adc_2 = ord(ser.read(1)) - 1
                    ADC = adc(adc_1, adc_2)
                    enc_1 = ord(ser.read(1)) - 1
                    enc_2 = ord(ser.read(1)) - 1
                    enc_3 = ord(ser.read(1)) - 1
                    ENC = enc(enc_1, enc_2, enc_3)
                    adc_down = ADC  # 上电初始位置为ADC_down
                    print('>>>初始位置下，ADC=', adc_down, 'ENC=', ENC)
                    adc_aim = (2048 + adc_down) % 4095  # 目标值
                    if useHandMode:
                        adc_aim = userSetADCaim
                        adc_down = userSetdown
                    print('>>>目标位置为，ADC=', adc_aim)
                    continue
                else:
                    ###########################
                    # 判定是否开始计时
                    # 如果开始计时，判定是否稳定于目标
                    # TODO: 稳定区域和开始区域的参数调整
                    ###########################
                    adc_1 = ord(ser.read(1)) - 1
                    adc_2 = ord(ser.read(1)) - 1
                    ADC = adc(adc_1, adc_2)
                    enc_1 = ord(ser.read(1)) - 1
                    enc_2 = ord(ser.read(1)) - 1
                    enc_3 = ord(ser.read(1)) - 1
                    ENC = enc(enc_1, enc_2, enc_3)
                    #print('ENC',ENC,'ADC',ADC)
                    if start_flag == 0 and not ADCinrange(ADC, adc_down):
                        print('>>>计时开始')
                        start_flag = 1
                        t = 1
                if start_flag == 1:
                    enc_queue.put(ENC)
                    if ADCinrange(ADC, adc_aim):
                        endCount = endCount + 1
                    else:
                        endCount = 0
                    ax.append(t * 0.005)  # 添加 t 到 x 轴的数据中
                    ay.append(ADC)  # 添加 ADC到 y 轴的数据中
                    az.append(ENC)  # 添加 ADC到 y 轴的数据中
                    isENCsteady = ENCsteady()
                    isADCsteady = endCount >= 200 * steady_time
                ###########################
                # 稳定1s停止
                # TODO: 3*200*5ms==3s。3s是否合理
                ###########################
                if isENCsteady and isADCsteady:
                    data_adc.close()
                    data_adc = open(team_name + 'task_1_ADC.txt', 'a')
                    data_enc.close()
                    data_enc = open(team_name + 'task_1_ENC.txt', 'a')
                    break
    print('>>>结束')
    ser.close()  # 关闭串口
    print('>>>最终耗时:', t * 0.005, 's')
except Exception as e:
    print(">>>异常:", e)

# draw
try:
    plt.subplot(1, 2, 1)  # 要生成两行两列，这是第一个图plt.subplot('行','列','编号')
    plt.plot(ax, ay)  # 画出当前 ax 列表和 ay 列表中的值的图形
    plt.ylabel('ADC')
    plt.xlabel('time/s')
    for i in range(0, t - 1):
        if ADCinrange(ay[i], adc_aim):
            plt.annotate(s='.', xy=(round(ax[i], 3), ay[i]),
                         xytext=(0, 0), textcoords='offset points')

    plt.subplot(1, 2, 2)  # 两行两列,这是第二个图
    plt.plot(ax, az)  # 画出当前 ax 列表和 ay 列表中的值的图形
    plt.ylabel('ENC')
    plt.xlabel('time (s)')
    plt.show()
except Exception as e:
    print(">>>异常:", e)
